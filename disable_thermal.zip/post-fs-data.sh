#!/system/bin/sh

# 延迟一点时间，确保节点加载完成
sleep 5

THERMAL_PATH="/sys/class/thermal"

# 禁用 cooling_device*
for dev in $THERMAL_PATH/cooling_device*; do
    [ -w "$dev/cur_state" ] && echo 0 > "$dev/cur_state"
    [ -w "$dev/mode" ] && echo "disabled" > "$dev/mode"
done

# 禁用 thermal_zone*
for zone in $THERMAL_PATH/thermal_zone*; do
    [ -w "$zone/mode" ] && echo "disabled" > "$zone/mode"
    [ -w "$zone/passive" ] && echo 0 > "$zone/passive"
done
